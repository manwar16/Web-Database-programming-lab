<footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
      </div>
      <strong>Copyright:Nusrat Jahan Muna<br>Powered By:Digitalworld Site
      
        </strong>
    </div>
</footer>